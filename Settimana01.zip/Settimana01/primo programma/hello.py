# primo programma in Python
# stampa un semplice messaggio di benvenuto
print('Buongiorno a tutti')
print(3)
print(3+2)
print("3+2")
print(5)