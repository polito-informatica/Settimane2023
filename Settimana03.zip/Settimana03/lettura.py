print('inserisci 2 numeri')

primo = int(input("Inserisci il primo numero: "))
secondo = int(input("Inserisci il secondo numero: "))
print(f"{primo=}")

nome = input("Il tuo nome: ")

somma = primo + secondo

print("La somma vale", somma)
print(f"La somma vale {primo+secondo} e la differenza è {abs(primo-secondo)}")

print("Ti chiami: ", nome)