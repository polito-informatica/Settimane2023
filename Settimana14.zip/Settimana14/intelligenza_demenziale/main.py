# Scrivere il programma all'interno di questo file 'main.py'
# Non creare altre cartelle o altri file, altrimenti essi non verranno
# consegnati né valutati.


# questa istruzione è utile a verificare che il programma parta correttamente
# e riesca a leggere il file. Deve essere cancellata nella vostra versione
# del programma
print(open('promessisposi.txt', 'r', encoding='utf-8').read()[:2000])