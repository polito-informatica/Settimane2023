nome = 'ciaobbelli'

for i in range(len(nome)):
    print(nome[i], i)

# i = 0
# for ch in nome:
#     print(ch, i)
#     i = i + 1
# print(nome)

# i = 0
# while i<len(nome):
#     print(nome[i], i)
#     i = i+1

# for i, ch in enumerate(nome):
#     print(ch, i)