def doppio(x):
    x = x * 2
    return x

def stampa_decorato(n):
    print("***", n, "***")
    return

y = 5
y = doppio(y)
valore = stampa_decorato(y)
print(valore)